AIM HUB — VERSION LOCALE HTML 1.6

Conception : Cotarta Anca-Madalina

OUVERTURE
1. Décompresser le fichier ZIP.
2. Ouvrir le dossier « AIM-France-site-local ».
3. Double-cliquer sur « index.html ».

Le site fonctionne localement dans le navigateur : aucun hébergement,
aucune adresse web publique et aucune connexion ChatGPT ne sont nécessaires.

LIENS SHAREPOINT
Les boutons vers SharePoint restent disponibles. Ils ouvrent les dossiers
Allianz dans le navigateur et nécessitent les droits Microsoft/Allianz habituels.

IMPORTANT
Conserver ensemble index.html, styles.css, app.js, data.js, config.js,
ainsi que les dossiers assets et documents.

CLASSIFICATION : INTERNAL

/*
 * Configuration centralisée des liens.
 * Remplacer les valeurs "url" encore vides par les URL SharePoint https://... réelles.
 * Tant qu'une URL n'est pas renseignée, AIM Hub propose le chemin réseau/local
 * et un bouton pour le copier.
 */
window.AIM_CONFIG = {
  version: "1.6",
  updatedAt: "7 septembre 2026",
  classification: "INTERNAL",
  links: {
    teamRoot: {
      label: "Espace Équipe & missions",
      path: String.raw`C:\Users\COTARTA\Allianz\AZFR-INVEST_STRATEGY - Investment Management\030-Team and tasks`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2F030%2DTeam%20and%20tasks&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    newcomerFolder: {
      label: "Process & formulaires nouvel arrivant",
      path: String.raw`C:\Users\COTARTA\Allianz\AZFR-INVEST_STRATEGY - Investment Management\030-Team and tasks\Dossier RH\Process nouvel arrivant`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2F030%2DTeam%20and%20tasks%2FDossier%20RH%2FProcess%20nouvel%20arrivant&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    bloombergProcedure: {
      label: "Procédure Bloomberg",
      path: String.raw`S:\AIM\AIMPARIS_DPI\031-Investment framework\031-Procédures\Bloomberg`,
      url: ""
    },
    transactions: {
      label: "Fichier de transactions",
      path: String.raw`\\Qf53420\esp5\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\03-IM\045 - Portfolio Steering\041 - Transactions file`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2F045%20%2D%20Portfolio%20Steering%2F041%20%2D%20Transactions%20file&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    transactionImports: {
      label: "Dépôt des fichiers de transactions AM",
      path: String.raw`\\Qf53420\esp5\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\03-IM\039-Transactions`,
      url: ""
    },
    portfolioMonitoring: {
      label: "Portfolio Monitoring",
      path: String.raw`\\Qf53420\esp5\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\03-IM\045 - Portfolio Steering\0451 - Portfolio Monitoring`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2F045%20%2D%20Portfolio%20Steering%2F0451%20%2D%20Portfolio%20Monitoring&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    durationSteering: {
      label: "Duration Steering",
      path: String.raw`\\Qf53420\esp5\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\03-IM\045 - Portfolio Steering\0452 - Outils de gestion FI\Steering Duration`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2F045%20%2D%20Portfolio%20Steering%2F0452%20%2D%20Outils%20de%20gestion%20FI%2FSteering%20Duration&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    pnlSteering: {
      label: "P&L Steering Tool",
      path: String.raw`\\Qf53420\esp5\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\03-IM\045 - Portfolio Steering\0453 - P&L Steering\P&L Steering Tool_IS`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2F045%20%2D%20Portfolio%20Steering%2F0453%20%2D%20P%26L%20Steering&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    bloombergPortfolio: {
      label: "Actualiser la BPN sur Bloomberg",
      path: String.raw`\\Qf53420\esp5\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\03-IM\045 - Portfolio Steering\0452 - Outils de gestion FI\Actualiser portefeuilles Bloomberg\Portfolio Bloomberg.xlsm`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2F045%20%2D%20Portfolio%20Steering%2F0452%20%2D%20Outils%20de%20gestion%20FI%2FActualiser%20portefeuilles%20Bloomberg&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    bloombergTransactions: {
      label: "Actualiser les transactions dans Bloomberg",
      path: String.raw`S:\AIM\AIMPARIS_DPI\03-IM_Macros\Actualiser portefeuilles Bloomberg\Transactions`,
      url: ""
    },
    fifo: {
      label: "Piles FIFO SAPIMA",
      path: String.raw`\\Qf53420\esp5\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\03-IM\FIFO`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-9179374/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D9179374%2FShared%20Documents%2FInvestment%20Management%2FFIFO&viewid=edd6203f%2D41b1%2D43e2%2Dafa5%2Dc4ea3140d804"
    },
    financeRoot: {
      label: "Espace de partage Finance",
      path: String.raw`AIM Finance\Partage\Partage IS-Finance`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-4311609/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D4311609%2FShared%20Documents%2FPartage%2FPartage%20IS%2DFinance&viewid=cdcf13e1%2Dd9f6%2D4c11%2Dae1d%2Dd134e9175808"
    },
    financeRgl: {
      label: "Suivi RGL",
      path: String.raw`S:\AIM\AIMPARIS_DPI\08-AIM Finance\01 Planning and Controlling\3 Investment Dialog\2022\2 - Input\RGL`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-4311609/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D4311609%2FShared%20Documents%2FPartage%2FPartage%20IS%2DFinance%2F2026%2FClosing&viewid=cdcf13e1%2Dd9f6%2D4c11%2Dae1d%2Dd134e9175808"
    },
    financeNopPc: {
      label: "NOP PC",
      path: String.raw`\\groupe.ad.agf.fr\ile_de_france\Projets-05\UNITE_INVESTISSEMENT\AIM\AIMPARIS_DPI\08-AIM Finance\01 Planning and Controlling\3 Investment Dialog\2022\6-Topics\NOP PC\NOP PC.xlsx`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-4311609/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D4311609%2FShared%20Documents%2FPartage%2FPartage%20IS%2DFinance&viewid=cdcf13e1%2Dd9f6%2D4c11%2Dae1d%2Dd134e9175808"
    },
    financeTac: {
      label: "TAC mensuel",
      path: String.raw`S:\AIM\AIMPARIS_DPI\06-Monitoring\061-Données\0612-Stocks\Base Père Noël\2021\Contrôles\BPN 12-21`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-4311609/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D4311609%2FShared%20Documents%2FPartage%2FBPN%2F2026%2FContr%C3%B4les&viewid=cdcf13e1%2Dd9f6%2D4c11%2Dae1d%2Dd134e9175808"
    },
    bpn: {
      label: "Base de données BPN",
      path: String.raw`S:\AIM\AIMPARIS_DPI\06-Monitoring\061-Données\0612-Stocks\Base Père Noël`,
      url: "https://allianzms.sharepoint.com/teams/FR0023-4311609/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FFR0023%2D4311609%2FShared%20Documents%2FPartage%2FBPN&viewid=cdcf13e1%2Dd9f6%2D4c11%2Dae1d%2Dd134e9175808"
    },
    saaReport: {
      label: "Rapport SAA",
      path: String.raw`S:\AIM\AIMPARIS_DPI\06-Monitoring\063-Reporting\Reporting MIS\Rapport SAA`,
      url: ""
    },
    orders: {
      label: "Historisation des ordres",
      path: String.raw`S:\AIM\AIMPARIS_DPI\03-IM_Macros\Historisation des ordres`,
      url: ""
    },
    marketUpdate: {
      label: "Market Update",
      path: String.raw`S:\AIM\AIMPARIS_DPI\11-Comités\1145-Réunion marchés\Market update`,
      url: ""
    },
    meetingMarket: {
      label: "Réunion de marché",
      path: String.raw`S:\AIM\AIMPARIS_DPI\11-Comités\1145-Réunion marchés\Réunion de marché`,
      url: ""
    }
  }
};

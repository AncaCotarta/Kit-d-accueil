window.AIM_DATA = {
  onboarding: [
    {
      id: "before",
      title: "Avant l’arrivée",
      eyebrow: "Préparer",
      items: [
        { id: "dicid", title: "Récupérer le DICID", detail: "Demande auprès des RH / Rafaela. Le DICID conditionne la création de l’adresse e-mail et plusieurs accès.", owner: "RH / Rafaela" },
        { id: "equipment", title: "Commander le matériel", detail: "Ordinateur portable, base fixe, deux écrans et téléphone.", owner: "Rafaela" }
      ]
    },
    {
      id: "core-access",
      title: "Accès essentiels",
      eyebrow: "Jour 1",
      items: [
        { id: "email-office", title: "Activer e-mail et Office", detail: "Appeler le 85 2000 avec le DICID pour l’adresse e-mail et l’accès Office.", owner: "Support 85 2000" },
        { id: "network", title: "Demander l’accès réseau", detail: "Lancer la demande une fois le DICID disponible.", owner: "Support IT" },
        { id: "checkpoint", title: "Configurer Check Point", detail: "Faire activer l’accès distant / VPN selon le poste.", owner: "Support IT" },
        { id: "teams", title: "Vérifier Teams", detail: "Connexion, appartenance aux équipes et accès aux canaux nécessaires.", owner: "Manager / équipe" },
        { id: "printer", title: "Installer l’imprimante", detail: "Utiliser le logiciel PlugAndPrint.", owner: "Support IT" }
      ]
    },
    {
      id: "business-access",
      title: "Outils métier",
      eyebrow: "Semaine 1",
      items: [
        { id: "az-connect", title: "AZ Connect Pages", detail: "Faire vérifier ou attribuer les accès nécessaires.", owner: "Hafsa" },
        { id: "atp", title: "ATP virements", detail: "Demander l’habilitation correspondant aux virements.", owner: "Nicolas Cabrera" },
        { id: "bloomberg", title: "Bloomberg", detail: "Remplir les formulaires, faire valider l’identifiant à utiliser et demander l’accès aux indices JP Morgan.", owner: "Marc Brochard / Jens", linkKey: "bloombergProcedure" },
        { id: "mis", title: "MIS", detail: "Remplir le formulaire MIS et le transmettre à Marwen Najar ou adjui_daniel.kouadio@allianz.fr.", owner: "Marwen Najar" },
        { id: "pico", title: "PICO", detail: "Remplir le formulaire PICO et le transmettre à Marwen.", owner: "Marwen Najar" },
        { id: "sapima", title: "SAPIMA", detail: "Faire la demande via MyAlicia.", owner: "MyAlicia" }
      ]
    },
    {
      id: "data-access",
      title: "Données & reporting",
      eyebrow: "Habilitations",
      items: [
        { id: "annecy-reader", title: "Data Platform – Annecy", detail: "Rôle à demander : Data Platform-Annecy Production-prod-reader.", owner: "Data Management" },
        { id: "is-reader", title: "Data Platform – Investment Strategy", detail: "Rôle à demander : Data Platform-Investment Strategy-prod-reader.", owner: "Data Management" },
        { id: "ids-rls", title: "IDS Power BI – RLS", detail: "Rôle à demander : AZU-IDS-PBI-RLS-AIM-FR.", owner: "Data Management" },
        { id: "ids-power", title: "IDS Power Data", detail: "Rôle à demander : PBI_IDS_AIM_Power_Data_V.", owner: "Data Management" }
      ]
    },
    {
      id: "business-basics",
      title: "Repères métier",
      eyebrow: "Semaine 2",
      items: [
        { id: "aim-role", title: "Comprendre le rôle d’AIM", detail: "Distinguer la décision d’allocation, la définition de la SAA par l’ALM et la sélection des titres par les Asset Managers.", owner: "Manager / binôme", route: "equipe" },
        { id: "portfolio-segments", title: "Lire les périmètres LH et PC", detail: "Identifier les horizons de passif, les entités et les spécificités de duration des deux périmètres.", owner: "Manager / binôme", route: "equipe" },
        { id: "bpn-mis-basics", title: "Prendre en main BPN, MIS et le rapport SAA", detail: "Savoir choisir la bonne vue, appliquer les filtres clés et comparer allocation cible et allocation actuelle.", owner: "Équipe AIM", route: "outils" },
        { id: "orders-liquidity", title: "Comprendre les ordres et la liquidité", detail: "Revoir le principe saisisseur/valideur, les virements ATP et le rôle pivot de la poche Trésorerie.", owner: "Équipe AIM", route: "outils" }
      ]
    }
  ],

  teamLeads: [
    { name: "Matthieu Durin", initials: "MD", role: "Chief Investment Management & Asset and Liability Management", pillar: "Direction" },
    { name: "Geoffrey Kam Essako", initials: "GKE", role: "Head ALM / SAA", pillar: "Gestion Actif-Passif" },
    { name: "Charles Picard", initials: "CP", role: "Head of Trade Assets", pillar: "Actifs cotés" },
    { name: "Guillaume Collet", initials: "GC", role: "Head of Alternative Assets", pillar: "Actifs alternatifs" }
  ],

  widerTeam: [
    { name: "Nicolas Boulet", role: "Directeur des investissements" },
    { name: "Roger Prestoz", role: "Développement produits & gestion des gestionnaires d’actifs" },
    { name: "Jens Koeke", role: "Finance & opérations" },
    { name: "Carlos Araujo", role: "Durabilité & compliance" },
    { name: "Anisa Caja", role: "Trésorerie" },
    { name: "Alain Dumas", role: "Équipe de gestion d’Allianz Patrimoine" }
  ],

  missions: [
    {
      number: "01",
      title: "Gestion de portefeuilles",
      description: "Mettre en œuvre l’allocation avec l’ALM, piloter cash, ventes et investissements, puis suivre rendement, performance et duration."
    },
    {
      number: "02",
      title: "Responsabilité de classe d’actifs",
      description: "Construire une vue locale, suivre mandats, fonds et ESG, puis proposer les stratégies ou deals pertinents aux gérants."
    },
    {
      number: "03",
      title: "Gestion Actif-Passif",
      description: "Assurer la cohérence du bilan, optimiser l’allocation et contribuer à la maîtrise des risques financiers."
    },
    {
      number: "04",
      title: "Reporting & communication",
      description: "Préparer les comités clients et reporter au LIMCo, au CIO, à AIM SE, aux fonctions Finance, Risques et Audit."
    }
  ],

  operatingModel: [
    {
      id: "aim",
      label: "AIM / gestion allocataire",
      title: "Décider de l’allocation",
      description: "AIM suit le portefeuille dans son ensemble — Fixed Income, actions, private equity et autres actifs — puis choisit les allocations, les stratégies et le rythme d’investissement.",
      example: "Exemple : décider d’allouer 10 M€ au High Yield, sans choisir chaque obligation."
    },
    {
      id: "alm",
      label: "ALM",
      title: "Traduire le passif en cible",
      description: "L’ALM analyse les engagements, construit la SAA et fixe les cibles de duration, de classes d’actifs, de sous-catégories et de maturités.",
      example: "Le passif est le point de départ de la structure cible du portefeuille."
    },
    {
      id: "asset-managers",
      label: "Asset Managers",
      title: "Implémenter et sélectionner",
      description: "AGI, PIMCO et les autres gérants mettent en œuvre les mandats et choisissent les instruments précis dans le cadre de l’allocation décidée.",
      example: "Le stock picking et l’exécution titre par titre relèvent des gérants."
    }
  ],

  portfolioSegments: [
    {
      id: "lh",
      code: "LH",
      title: "Life & Health",
      tone: "blue",
      horizon: "Passifs plutôt longs",
      description: "Le périmètre Vie, Santé et Retraite porte généralement des engagements de plus longue durée.",
      entities: "Allianz Vie, Génération Vie et Allianz Retraite."
    },
    {
      id: "pc",
      code: "PC",
      title: "Property & Casualty",
      tone: "orange",
      horizon: "Passifs plutôt courts",
      description: "Le périmètre IARD présente en général une duration plus faible, compte tenu de sinistres et flux plus court terme.",
      entities: "Une compagnie IARD, avec un PG et des portefeuilles au comptant."
    }
  ],

  allocationGuide: [
    {
      number: "01",
      title: "SAA cible",
      description: "Structure de long terme définie annuellement avec l’ALM, par duration, classe d’actifs, sous-catégorie et maturité."
    },
    {
      number: "02",
      title: "Leeways & budgets",
      description: "Bornes de gestion et capacité disponible autour de la cible pour encadrer les décisions tactiques."
    },
    {
      number: "03",
      title: "TAA",
      description: "Ajustements temporaires décidés selon les marchés, les risques et les vues des experts de classes d’actifs."
    },
    {
      number: "04",
      title: "AAA vs SAA driftée",
      description: "Comparaison mensuelle dans MIS entre l’allocation actuelle et la cible impactée par les mouvements de marché YTD."
    }
  ],

  documents: [
    {
      id: "business-basics-note",
      title: "Fiche de repères métier",
      category: "Formation",
      description: "Synthèse structurée des rôles AIM / ALM / Asset Managers, de la SAA/TAA, de la BPN, de MIS, des ordres et de la liquidité.",
      file: "documents/fiche-reperes-metier.html",
      freshness: "Notes de travail intégrées le 7 septembre 2026"
    },
    {
      id: "newcomer-doc",
      title: "Process nouvel arrivant",
      category: "Onboarding",
      description: "Liste de contrôle des équipements, accès IT, outils métier et rôles data.",
      file: "documents/process-nouvel-arrivant.docx",
      linkKey: "newcomerFolder",
      freshness: "Source interne"
    },
    {
      id: "orders-doc",
      title: "Procédure fichier d’ordres",
      category: "Procédure",
      description: "Ajouter l’emplacement du fichier d’ordres aux emplacements approuvés d’Excel.",
      file: "documents/procedure-fichier-ordres.docx",
      linkKey: "orders",
      freshness: "Mis à jour en 2025"
    },
    {
      id: "tools-doc",
      title: "Outils internes",
      category: "Mode opératoire",
      description: "Fonctionnement et mise à jour des principaux outils de Portfolio Steering.",
      file: "documents/outils-internes.docx",
      linkKey: "portfolioMonitoring",
      freshness: "Source interne"
    },
    {
      id: "finance-doc",
      title: "Liens de la Finance",
      category: "Finance",
      description: "Accès au suivi RGL, au NOP PC et au fichier TAC.",
      file: "documents/liens-finance.docx",
      linkKey: "financeRoot",
      freshness: "Espace de partage Finance"
    },
    {
      id: "employee-offer",
      title: "Offre assurance employés Allianz",
      category: "Avantages salariés",
      description: "Présentation de l’offre salariés Mon Allianz en ligne. Vérifier les conditions en vigueur avant utilisation.",
      file: "documents/offre-assurance-employes-az.pdf",
      freshness: "Présentation de décembre 2021"
    },
    {
      id: "aim-presentation",
      title: "Présentation de l’Unité Investissements",
      category: "Équipe",
      description: "Organisation, chaîne de valeur, missions et principaux interlocuteurs d’AIM France.",
      file: "documents/presentation-aim-paris.pptx",
      linkKey: "teamRoot",
      freshness: "Novembre 2025"
    }
  ],

  tools: [
    {
      id: "transactions",
      title: "Fichier de transactions",
      short: "Consolide les transactions AIM, AGI, PIMCO et LBPAM sur l’année.",
      cadence: "Chaque vendredi soir",
      linkKey: "transactions",
      dependencies: ["ACTS", "Bloomberg", "Fichiers AGI / PIMCO / LBPAM"],
      steps: [
        "Chaque vendredi soir, enregistrer les fichiers reçus des Asset Managers dans le dossier 039-Transactions.",
        "Ouvrir l’onglet Tools et exécuter la macro.",
        "Contrôler la mise à jour de l’onglet Transactions Summary.",
        "En fin d’année, figer le fichier au 31/12 puis créer la version de l’année suivante."
      ]
    },
    {
      id: "portfolio-monitoring",
      title: "Portfolio Monitoring",
      short: "Suit achats, réinvestissements, ventes, maturités, Book Yields et durations.",
      cadence: "Chaque vendredi soir",
      linkKey: "portfolioMonitoring",
      dependencies: ["Fichier de transactions à jour"],
      steps: [
        "Mettre d’abord à jour le fichier de transactions.",
        "Exécuter la macro de l’onglet Tools.",
        "Utiliser InvReinvestment details pour choisir périmètre et dates.",
        "Vérifier Transactions Summary, Transactions Derives YtD, RE et Alternatif."
      ]
    },
    {
      id: "duration-steering",
      title: "Duration Steering",
      short: "Mesure les impacts de TAC, duration et consommation de réserve de capitalisation.",
      cadence: "Chaque vendredi soir · nouvelle version trimestrielle",
      linkKey: "durationSteering",
      dependencies: ["Fichier de transactions", "Portfolio Monitoring"],
      steps: [
        "Chaque trimestre, créer une nouvelle version du fichier.",
        "Chaque vendredi soir, exécuter la macro Tools après actualisation des dépendances.",
        "Dans Rapport, choisir la période et exécuter la macro Bouton.",
        "Contrôler Recap, RdC en YtD, Fwd Bonds Updated et Achats Ventes."
      ]
    },
    {
      id: "pnl-steering",
      title: "P&L Steering",
      short: "Synthétise exposition et PMVL, puis simule des ventes et la PMVR associée.",
      cadence: "À la demande",
      linkKey: "pnlSteering",
      dependencies: ["Pile FIFO SAPIMA HB0", "HB2 facultatif"],
      steps: [
        "Coller la pile FIFO HB0 dans l’onglet HB0.",
        "Exécuter la macro Template de l’onglet P&L.",
        "Choisir une simulation par PMVL cible ou Market Value cible.",
        "Contrôler quantité, Market Value, PMVR et réserves avant/après."
      ]
    },
    {
      id: "bpn-bloomberg",
      title: "Actualiser la BPN sur Bloomberg",
      short: "Met à jour sur Bloomberg les maturités et coupons calculés à partir de la BPN.",
      cadence: "À chaque nouvelle BPN",
      linkKey: "bloombergPortfolio",
      dependencies: ["BPN", "Accès PORT / BBU Bloomberg"],
      steps: [
        "Mettre à jour année, mois et jour dans la feuille taux.",
        "Uploader les lignes et enregistrer le fichier port.xlsx généré.",
        "Dans Bloomberg BBU, charger le fichier et valider le mappage.",
        "Partager les nouveaux portefeuilles via PRTU si nécessaire."
      ]
    },
    {
      id: "bloomberg-transactions",
      title: "Actualiser les transactions dans Bloomberg",
      short: "Génère un fichier port.xlsx prêt à être importé dans Bloomberg à partir du Fichier de transactions.",
      cadence: "Après l’actualisation de la BPN sur Bloomberg",
      linkKey: "bloombergTransactions",
      dependencies: ["Fichier de transactions.xlsm", "Transactions summary", "Matching ID", "Accès Bloomberg"],
      steps: [
        "Dans Fichier de transactions.xlsm, contrôler l’onglet Transactions summary et les colonnes Portfolio, Sub Portfolio, ISIN, Trade Date et Nominal.",
        "Dans le fichier Bloomberg Transaction Export, lancer le bouton Export_Port_Bloomberg.",
        "Le matching utilise l’onglet Matching ID et la clé Portfolio & Sub Portfolio pour retrouver l’ID cible de la macro.",
        "Pour un nouveau portefeuille, renseigner l’InputBox : le nouvel identifiant est ajouté automatiquement au matching.",
        "Contrôler le fichier port.xlsx créé dans le même dossier, onglet bloom, avec les colonnes Portfolio, ISIN, Trade Date et Nominal, puis l’importer dans Bloomberg."
      ],
      notes: [
        "Ce processus intervient après l’actualisation de la BPN dans Bloomberg.",
        "Vérifier les identifiants de portefeuille et les dates avant de lancer l’import."
      ],
      image: "assets/bloomberg-transaction-export.png",
      imageAlt: "Interface Bloomberg Transaction Export présentant la source, le matching et l’export Bloomberg"
    },
    {
      id: "fifo-sapima",
      title: "Piles FIFO SAPIMA",
      short: "Produit la transparisation ligne à ligne HB0/HB2 des fonds d’un portefeuille poche S.",
      cadence: "À la demande",
      linkKey: "fifo",
      dependencies: ["SAPIMA", "Macro FIFO", "Extractions MOP et TPM12"],
      steps: [
        "Extraire MOP_POS_REP avec la variante ALV FIFO.",
        "Extraire TPM12 avec le layout PILE FIFO.",
        "Coller les deux extractions dans les onglets MOP et TPM12.",
        "Exécuter PILES FIFO puis conserver les onglets HB0 et HB2."
      ]
    },
    {
      id: "bpn-guide",
      title: "Base de données BPN",
      short: "Base de données fournie par la Finance, généralement au milieu du mois, regroupant le stock des actifs en HB0 avec les valeurs boursières, comptables et les segmentations de portefeuille.",
      cadence: "Mensuel · généralement au milieu du mois",
      linkKey: "bpn",
      dependencies: ["Finance", "BPN", "HB0", "CART level", "Middle Office Portfolio"],
      steps: [
        "Exclure Unit Linked dans la colonne E pour travailler sur le périmètre général décrit.",
        "Filtrer la colonne P / Middle Office Portfolio pour sélectionner les poches ou mandats utiles.",
        "Utiliser la valeur comptable HB0 pour les analyses de TAC ; utiliser les expositions pour les analyses de duration.",
        "Contrôler le CART level, le pays de risque émetteur et le niveau de transparisation avant toute agrégation."
      ],
      notes: [
        "Dans la version documentée, le TAC / Book Yield est en colonne AW et le risque émetteur en colonne CM.",
        "Les fonds apparaissent généralement sur une ligne non transparisée, contrairement aux portefeuilles détaillés ligne à ligne.",
        "Les lettres de colonnes peuvent évoluer : vérifier les en-têtes avant d’appliquer un filtre ou une formule."
      ]
    },
    {
      id: "saa-report",
      title: "Rapport SAA",
      short: "Compare l’allocation cible stratégique avec l’allocation actuelle et les marges tactiques du portefeuille.",
      cadence: "Mensuel",
      linkKey: "saaReport",
      dependencies: ["MIS", "SAA ALM", "AAA", "Leeways", "Budgets"],
      steps: [
        "Sélectionner le portefeuille et vérifier le périmètre LH ou PC.",
        "Comparer la SAA cible, la SAA driftée et l’AAA sur les classes et sous-catégories d’actifs.",
        "Analyser la duration sur le seul périmètre Fixed Income ainsi que les maturités 1–3Y, 3–5Y, etc.",
        "Positionner la TAA en tenant compte des leeways, des budgets et des vues des experts de classes d’actifs."
      ],
      notes: [
        "Dans la version observée : colonne G = allocation cible, H = allocation actuelle et J = montant en millions.",
        "La SAA est définie pour une année civile ; sa version driftée intègre les mouvements de marché depuis le début de l’année."
      ]
    },
    {
      id: "mis-guide",
      title: "Utiliser MIS",
      short: "Consulte les vues HB2, les rapports standards, les données transparisées et les analyses par portefeuille.",
      cadence: "Mensuel / à la demande",
      dependencies: ["MIS Explorer", "Analysis Studio", "MIS Handbook", "HB2"],
      steps: [
        "Commencer par MIS Explorer et réutiliser un rapport standard par segment LH / PC ou par portefeuille.",
        "Utiliser MIS Analysis Studio seulement lorsqu’une analyse doit être construite depuis zéro.",
        "Consulter le MIS Handbook pour la définition d’une variable et son emplacement.",
        "Pour retrouver un titre dans Analysis Studio : Investment Identifiers → AIM Identifiers, puis rechercher l’ISIN ou le nom."
      ],
      notes: [
        "MIS porte la vue groupe / IFRS HB2 ; la BPN porte la vue locale HB0 dans les notes fournies.",
        "AIDA est présenté comme le nouvel environnement Power BI appelé à reprendre des usages MIS.",
        "Le mapping “Actual / Enhanced” avec la transparisation reste à confirmer avant diffusion comme règle."
      ]
    },
    {
      id: "liquidity-planning",
      title: "Liquidity Planning",
      short: "Pilote les besoins et excédents de cash à environ un mois en utilisant la poche Trésorerie comme pivot.",
      cadence: "Tous les 15 jours",
      dependencies: ["Cash Management", "ALM", "Poche Trésorerie", "Portefeuilles"],
      steps: [
        "Participer à la réunion avec Cash Management, les gérants TAA et au moins un représentant ALM.",
        "Prendre connaissance des besoins ou excédents de cash à horizon d’environ un mois et du coussin minimal de liquidité.",
        "Pour transférer de X vers Y, effectuer X → Trésorerie puis Trésorerie → Y.",
        "Mettre les besoins à disposition, ou investir les excédents, à la date communiquée par Cash Management."
      ],
      notes: [
        "Les recommandations couvrent les flux d’exploitation et techniques ; coupons, maturités et cash des poches gérées restent sous la responsabilité des Asset Managers.",
        "La poche Settlement (S) fait partie de la poche Trésorerie : aucun virement intermédiaire n’est nécessaire entre S et Trésorerie."
      ]
    },
    {
      id: "orders-workflow",
      title: "Saisir et tracer les ordres",
      short: "Distingue les ordres de fonds dans Bloomberg des virements inter-poches de trésorerie dans ATP.",
      cadence: "À chaque ordre",
      linkKey: "orders",
      dependencies: ["Bloomberg", "ATP", "Principe saisisseur / valideur", "Historique des ordres"],
      steps: [
        "Identifier le canal : Bloomberg pour les ordres de fonds ; ATP pour injecter, extraire ou déplacer du cash entre poches.",
        "Respecter la séparation des rôles : l’émetteur d’un ordre ne peut pas valider ce même ordre.",
        "Dans ATP, sélectionner la poche source et utiliser SELL lorsqu’on en retire du cash ; utiliser BUY dans le sens inverse.",
        "Après traitement, enregistrer systématiquement l’opération dans l’historique des ordres."
      ],
      notes: [
        "Dans l’organisation décrite par les notes, Sonia intervient comme valideur et les gérants comme saisisseurs ; confirmer les délégations en vigueur.",
        "Toujours contrôler le portefeuille, la poche de départ, la poche d’arrivée, le sens et le montant avant validation."
      ]
    }
  ],

  financeLinks: [
    { title: "Suivi des RGL", description: "Suivi des résultats de gestion latents/réalisés en HB0 et HB2, en réel et en estimation.", linkKey: "financeRgl", note: "Dossier Closing 2026." },
    { title: "NOP PC", description: "Fichier de suivi du résultat non opérationnel pour le périmètre Property & Casualty.", linkKey: "financeNopPc", note: "Lien général Finance utilisé dans l’attente du dossier NOP à jour." },
    { title: "TAC mensuel", description: "Fichier Finance utilisé pour le suivi du taux actuariel / rendement comptable.", linkKey: "financeTac", note: "Dossier Contrôles BPN 2026." }
  ],

  glossary: [
    { term: "AAA", expansion: "Actual Asset Allocation", definition: "Allocation d’actifs réellement observée à une date donnée, comparée dans le rapport SAA à la cible stratégique et à la SAA driftée.", category: "Allocation" },
    { term: "ABS", expansion: "Asset-Backed Securities", definition: "Titre financier adossé à un portefeuille d’actifs ou de créances, dont les flux servent au paiement des intérêts et du principal.", category: "Classes d’actifs" },
    { term: "ACM", expansion: "Allianz Customer Model", definition: "Modèle client Allianz utilisé dans les travaux internes.", category: "Modèles" },
    { term: "ACT", expansion: "Mandat Actions", definition: "Code de mandat utilisé pour la poche actions.", category: "Mandats" },
    { term: "ACTS", expansion: "Outil de trésorerie", definition: "Outil utilisé pour les opérations et données de trésorerie.", category: "Outils" },
    { term: "AGI", expansion: "Allianz Global Investors", definition: "Gestionnaire d’actifs du groupe ; notamment référencé pour des mandats obligataires.", category: "Organisation" },
    { term: "AIM SE", expansion: "Allianz Investment Management SE", definition: "Entité AIM au niveau du Groupe Allianz.", category: "Organisation" },
    { term: "AT", expansion: "Portefeuilles retraite", definition: "Code utilisé pour les portefeuilles ou mandats retraite.", category: "Portefeuilles" },
    { term: "BBA", expansion: "Building Blocks Approach", definition: "Modèle général d’évaluation des contrats d’assurance sous IFRS 17, hors modèles spécifiques applicables.", category: "IFRS" },
    { term: "BPN", expansion: "Base Père Noël", definition: "Base HB0 recensant les actifs des portefeuilles en valeurs boursière et comptable, avec données de marché et segmentations. Elle est très exhaustive, mais les fonds y apparaissent sans transparisation, sur une seule ligne.", category: "Données" },
    { term: "BY", expansion: "Book Yield", definition: "Terme utilisé dans les outils de monitoring pour le rendement comptable.", category: "Performance" },
    { term: "Cash change", expansion: "Variation de cash", definition: "Cash de fin de période moins cash de début de période.", category: "Trésorerie" },
    { term: "COP", expansion: "Comité client", definition: "Comité de suivi et de décision avec les clients internes ou externes concernés.", category: "Gouvernance" },
    { term: "Core net income", expansion: "Résultat net cœur", definition: "Résultat net retraité notamment de l’ECL, du Valuation Result, des impairments et de l’amortissement des incorporels.", category: "Résultat" },
    { term: "CR", expansion: "Mandat Crédit AGI", definition: "Code interne pour un mandat crédit géré par Allianz Global Investors.", category: "Mandats" },
    { term: "CSM", expansion: "Contractual Service Margin", definition: "Stock de profits attendus à la souscription, reconnu en résultat au fur et à mesure du service rendu pendant la couverture.", category: "IFRS" },
    { term: "D", expansion: "Mandat dérivé", definition: "Code de mandat utilisé pour les instruments dérivés.", category: "Mandats" },
    { term: "DM", expansion: "Data Management", definition: "Fonction responsable de la gestion, de la qualité et de la mise à disposition des données.", category: "Données" },
    { term: "Duration gap", expansion: "Écart de duration", definition: "Écart entre la duration, ou vie moyenne sensible aux taux, du portefeuille d’actifs et celle des passifs.", category: "ALM" },
    { term: "DwH", expansion: "Data Warehouse", definition: "Entrepôt de données centralisant des informations structurées pour les usages de reporting et d’analyse.", category: "Données" },
    { term: "ECL", expansion: "Expected Credit Loss", definition: "Provision pour pertes de crédit attendues sous IFRS 9. Stage 1 : pertes attendues à 12 mois ; Stage 2 : pertes sur la durée de vie après hausse significative du risque ; Stage 3 : actifs dépréciés ou en défaut.", category: "IFRS", images: ["assets/ecl-ifrs9-volatility.png"] },
    { term: "EM", expansion: "Emerging Markets", definition: "Marchés émergents.", category: "Classes d’actifs" },
    { term: "EMD", expansion: "Emerging Market Debt", definition: "Dette des marchés émergents.", category: "Classes d’actifs" },
    { term: "ETNC", expansion: "États et Territoires Non Coopératifs", definition: "Juridictions figurant sur les listes de territoires non coopératifs. Équivalent anglais cité : NCST, Non-Cooperative States and Territories.", category: "Conformité" },
    { term: "GACPA", expansion: "Comptabilité", definition: "Acronyme interne associé à la fonction comptable.", category: "Organisation" },
    { term: "GAET", expansion: "Group Enterprise Architecture Tool", definition: "Référentiel décrivant les grands processus, les outils et les solutions informatiques qui les sous-tendent, jusqu’aux serveurs.", category: "Outils" },
    { term: "HB0", expansion: "French GAAP / normes locales", definition: "Vue comptable locale française, notamment utilisée pour la vision stock de la BPN et la Book Value.", category: "Comptabilité" },
    { term: "HC", expansion: "Hard Currency", definition: "Dette émergente libellée dans une devise forte, généralement USD ou EUR.", category: "Classes d’actifs" },
    { term: "HY", expansion: "High Yield", definition: "Code de mandat ou segment obligataire à haut rendement, généralement de notation inférieure à Investment Grade.", category: "Mandats" },
    { term: "IDS", expansion: "Entrepôt de données du Groupe", definition: "Réunit les données d’actifs et les services associés : reporting, performance, risque, produits financiers et prévisions.", category: "Données" },
    { term: "IFRS 9", expansion: "Norme sur les instruments financiers", definition: "Norme comptable couvrant notamment classification, valorisation et dépréciation des actifs financiers via l’ECL.", category: "IFRS", images: ["assets/ecl-ifrs9-volatility.png", "assets/ifrs-principles-1.png"] },
    { term: "IFRS 17", expansion: "Norme sur les contrats d’assurance", definition: "Norme comptable introduisant une évaluation renouvelée des contrats d’assurance et une reconnaissance progressive des profits.", category: "IFRS", images: ["assets/ifrs-principles-1.png", "assets/ifrs-principles-2.png"] },
    { term: "ILB", expansion: "Inflation-Linked Bonds", definition: "Obligations indexées sur l’inflation.", category: "Classes d’actifs" },
    { term: "ILB SAA", expansion: "Allocation stratégique en obligations indexées", definition: "Poche ILB définie dans l’allocation stratégique d’actifs.", category: "Allocation" },
    { term: "INF", expansion: "Mandat Infrastructure", definition: "Code de mandat utilisé pour la poche infrastructure.", category: "Mandats" },
    { term: "IPO", expansion: "Initial Public Offering", definition: "Introduction en bourse d’une entreprise.", category: "Marchés" },
    { term: "LC", expansion: "Local Currency", definition: "Dette émergente libellée en devise locale. Le terme usuel est Local Currency.", category: "Classes d’actifs" },
    { term: "LH", expansion: "Life & Health", definition: "Périmètre Vie, Santé et Retraite. Ses passifs sont généralement plus longs que ceux du PC ; il regroupe Allianz Vie, Génération Vie et Allianz Retraite.", category: "Portefeuilles" },
    { term: "LIMCo", expansion: "Comité d’investissement Allianz France", definition: "Comité réuni environ cinq à six fois par an avec des membres du COMEX et de la Direction générale France.", category: "Gouvernance" },
    { term: "MID", expansion: "Mandat Private Placement", definition: "Code de mandat utilisé pour les placements privés.", category: "Mandats" },
    { term: "MIS", expansion: "Outil de gestion de portefeuille", definition: "Outil de gestion et de suivi de portefeuille utilisé en HB2.", category: "Outils" },
    { term: "Net income", expansion: "Résultat net", definition: "OP + NOP, puis prise en compte des taxes.", category: "Résultat" },
    { term: "NFI", expansion: "Équipe Finance", definition: "Équipe Finance en charge des sujets d’investissement liés au juridique, à la conformité et à d’autres contrôles ; contacts : Daniela et Jennifer.", category: "Organisation" },
    { term: "NOP", expansion: "Non-Operating Profit", definition: "Résultat non opérationnel. Pour le périmètre H&P évalué en BBA, inclut notamment le reclassement en non-opérationnel de produits financiers non récurrents selon les règles internes.", category: "Résultat", images: ["assets/op-nop-components.png"] },
    { term: "NOP AIM", expansion: "Composantes AIM du NOP", definition: "ECL + Valuation Result + Impairment.", category: "Résultat", images: ["assets/op-nop-components.png"] },
    { term: "Notionnel", expansion: "Montant de référence", definition: "Montant de référence utilisé pour calculer les flux d’un instrument. Selon le produit, il peut être calculé comme quantité × prix × spot de change.", category: "Marchés" },
    { term: "Novation", expansion: "Clôture / transfert d’un dérivé", definition: "Dans le process des hedge ratios, la position initiale est conservée et une opération inverse est enregistrée. Exemple : Long 10 M + Short 10 M = exposition nette nulle, tout en gardant la traçabilité et le P&L.", category: "Dérivés" },
    { term: "OP", expansion: "Operating Profit", definition: "Résultat opérationnel composé, dans la lecture fournie, de la marge technique, de la marge financière et d’autres revenus récurrents.", category: "Résultat", images: ["assets/op-nop-components.png"] },
    { term: "OW", expansion: "Overweight", definition: "Surpondération d’une classe d’actifs ou d’un titre par rapport à une allocation ou un indice de référence.", category: "Allocation" },
    { term: "P", expansion: "Mandat Crédit PIMCO", definition: "Code interne pour un mandat crédit géré par PIMCO.", category: "Mandats" },
    { term: "PAA", expansion: "Premium Allocation Approach", definition: "Approche simplifiée IFRS 17, principalement utilisée pour certains contrats de courte durée.", category: "IFRS", images: ["assets/ifrs-principles-2.png"] },
    { term: "PC", expansion: "Property & Casualty", definition: "Périmètre IARD / non-vie. Sa duration est généralement plus faible que celle du LH en raison de passifs liés aux sinistres et de flux plus court terme.", category: "Portefeuilles" },
    { term: "PD", expansion: "Planning Dialogue", definition: "Processus de construction et de discussion du budget.", category: "Planification" },
    { term: "PG", expansion: "Portefeuille général", definition: "Portefeuille pouvant contenir des fonds propres et contribuer aux dividendes ; exemples : PG Vie, PG AT et PG IARD.", category: "Portefeuilles" },
    { term: "PMVR", expansion: "Plus ou moins-value réalisée", definition: "Gain ou perte effectivement réalisé lors de la vente d’un actif.", category: "Performance" },
    { term: "PVFCF", expansion: "Present Value of Future Cash Flows", definition: "Somme actualisée de tous les flux futurs attendus liés à un contrat d’assurance : primes, prestations, frais, commissions, etc.", category: "IFRS" },
    { term: "RA", expansion: "Risk Adjustment", definition: "Ajustement IFRS 17 reflétant l’incertitude sur le montant et la date des flux de trésorerie non financiers.", category: "IFRS" },
    { term: "RdC", expansion: "Réserve de capitalisation", definition: "Réserve alimentée notamment par les plus-values sur cessions obligataires et destinée à absorber la dépréciation de certains actifs ou la diminution de leur revenu, selon les règles applicables.", category: "Comptabilité" },
    { term: "Redemptions", expansion: "Remboursements", definition: "Remboursements d’instruments, notamment à leur arrivée à échéance.", category: "Marchés" },
    { term: "S", expansion: "Poche Settlement", definition: "Code de poche utilisé pour le settlement / règlement.", category: "Portefeuilles" },
    { term: "SAA", expansion: "Strategic Asset Allocation", definition: "Allocation cible de long terme définie avec l’ALM pour une année civile, par duration, classe d’actifs, sous-catégorie et maturité, sous contraintes de risque et de passif.", category: "Allocation" },
    { term: "SIAT", expansion: "Outil de gestion des comptes bancaires", definition: "Outil interne utilisé pour la gestion des comptes bancaires.", category: "Outils" },
    { term: "SPIRE", expansion: "Single Platform Investment Repackaging Entity", definition: "Produit obligataire structuré de type repack, émis sous forme de note par un véhicule dédié et conçu à partir d’un sous-jacent pour obtenir un profil de risque et de rendement déterminé.", category: "Produits structurés" },
    { term: "Spread de crédit", expansion: "Écart de rendement de crédit", definition: "Écart de rendement entre une obligation risquée et une obligation sans risque de maturité comparable.", category: "Marchés" },
    { term: "SUB", expansion: "Mandat Subordonnée", definition: "Code de mandat utilisé pour la dette subordonnée.", category: "Mandats" },
    { term: "TAC", expansion: "Rendement actuariel comptable", definition: "Notion ex ante : rendement théorique ou carry si l’obligation est conservée jusqu’à maturité, sous les hypothèses du calcul.", category: "Performance" },
    { term: "Taux de rendement comptable projeté", expansion: "Rendement projeté", definition: "Projection combinant notamment le TAC pondéré des obligations, les PMVR attendues sur les actions et les dividendes.", category: "Performance" },
    { term: "Tréso", expansion: "Poche Trésorerie", definition: "Code de poche utilisé pour la trésorerie.", category: "Portefeuilles" },
    { term: "TX", expansion: "Mandat Taux", definition: "Code interne pour un mandat de taux.", category: "Mandats" },
    { term: "Valuation Result", expansion: "Résultat de valorisation", definition: "Impact en résultat lié aux variations de valorisation des actifs ou passifs selon le périmètre comptable.", category: "Résultat" },
    { term: "VFA", expansion: "Variable Fee Approach", definition: "Modèle IFRS 17 développé pour certains contrats participatifs.", category: "IFRS", images: ["assets/ifrs-principles-2.png"] },
    { term: "VIF", expansion: "Value in Force", definition: "Valeur actualisée des profits futurs que l’entreprise d’assurance prévoit de réaliser sur les contrats existants.", category: "Assurance" },
    { term: "WAKI score", expansion: "Weighted Average Key Issue Score", definition: "Score ESG synthétique obtenu en pondérant les scores relatifs aux principaux enjeux environnementaux, sociaux et de gouvernance selon leur importance pour le secteur de l’émetteur.", category: "ESG" },
    { term: "ALM", expansion: "Asset and Liability Management", definition: "Gestion Actif-Passif : pilotage conjoint des actifs et des engagements afin d’assurer la cohérence du bilan et la maîtrise des risques.", category: "ALM" },
    { term: "ATP", expansion: "Allianz Treasury Platform", definition: "Plateforme utilisée pour les ordres de trésorerie et les virements internes entre poches. La séparation saisisseur / valideur doit être respectée.", category: "Outils" },
    { term: "BBU", expansion: "Fonction Bloomberg d’import", definition: "Fonction utilisée dans la procédure interne pour charger le fichier port.xlsx et valider son mappage.", category: "Outils" },
    { term: "FIFO", expansion: "First In, First Out", definition: "Méthode considérant que les premières lignes acquises sont les premières cédées ; utilisée pour les piles SAPIMA HB0/HB2.", category: "Comptabilité" },
    { term: "HB2", expansion: "Vue Groupe / IFRS", definition: "Vue comptable Groupe fondée sur les normes IFRS, notamment utilisée dans MIS et plusieurs outils de suivi.", category: "Comptabilité" },
    { term: "ISIN", expansion: "International Securities Identification Number", definition: "Code international unique identifiant un instrument financier.", category: "Marchés" },
    { term: "MOP", expansion: "Rapport SAPIMA", definition: "Extraction MOP_POS_REP utilisée avec TPM12 pour générer les piles FIFO.", category: "Outils" },
    { term: "OAT", expansion: "Obligation assimilable du Trésor", definition: "Titre de dette émis par l’État français.", category: "Taux" },
    { term: "PBI", expansion: "Power BI", definition: "Outil Microsoft de visualisation et de reporting, notamment utilisé avec les données IDS.", category: "Outils" },
    { term: "PICO", expansion: "Plateforme de suivi des portefeuilles", definition: "Plateforme interne permettant de suivre l’ensemble des portefeuilles et d’en consulter le détail ligne à ligne.", category: "Outils" },
    { term: "PMVL", expansion: "Plus ou moins-value latente", definition: "Gain ou perte non encore réalisé, correspondant à l’écart entre la valeur actuelle et la valeur comptable ou le prix de revient selon le référentiel.", category: "Performance" },
    { term: "PORT", expansion: "Fonction portefeuille Bloomberg", definition: "Fonction utilisée pour consulter les portefeuilles et leurs cash-flows, coupons et maturités.", category: "Outils" },
    { term: "PRTU", expansion: "Fonction de partage Bloomberg", definition: "Fonction utilisée dans la procédure interne pour partager des portefeuilles et définir les permissions.", category: "Outils" },
    { term: "RGL", expansion: "Realized Gains and Losses", definition: "Gains et pertes réalisés.", category: "Résultat" },
    { term: "SAPIMA", expansion: "Outil interne de positions", definition: "Application utilisée notamment pour extraire MOP et TPM12 et produire les piles FIFO HB0/HB2.", category: "Outils" },
    { term: "TCD", expansion: "Tableau croisé dynamique", definition: "Outil Excel de synthèse et d’analyse de données, à actualiser lors des changements de source.", category: "Outils" },
    { term: "UC", expansion: "Unités de compte", definition: "Supports d’investissement de contrats d’assurance dont la valeur dépend des actifs sous-jacents et n’est pas garantie comme le fonds en euros.", category: "Assurance" },
    { term: "Accounting discount rate", expansion: "Taux actuariel comptable", definition: "Libellé associé au TAC actuariel dans la BPN. Le TAC actuariel est le taux de rendement théorique d’un actif obligataire calculé à partir de son prix, de ses flux futurs et de sa maturité.", category: "Performance" },
    { term: "AIDA", expansion: "Nouvel environnement de données AIM", definition: "Solution Power BI présentée dans les notes comme la nouvelle génération appelée à reprendre des usages de MIS.", category: "Outils" },
    { term: "Asset Manager", expansion: "Société ou équipe de gestion", definition: "Gérant chargé d’implémenter un mandat et de sélectionner les instruments précis dans le cadre de l’allocation décidée par AIM.", category: "Organisation" },
    { term: "Book Value", expansion: "Valeur comptable", definition: "Valeur d’un actif dans les comptes. Dans les notes BPN, la Book Value HB0 correspond à la vision comptable française.", category: "Comptabilité" },
    { term: "Cantons", expansion: "Portefeuilles isolés du portefeuille général", definition: "Sous-ensembles cantonnés avec actifs et passifs identifiés séparément du portefeuille général, selon le périmètre décrit.", category: "Portefeuilles" },
    { term: "Capital gain", expansion: "Plus-value en capital", definition: "Composante du rendement provenant de la hausse du prix d’un actif, par opposition aux revenus récurrents comme les dividendes ou coupons.", category: "Performance" },
    { term: "CART level", expansion: "Classification des actifs", definition: "Niveau de classification utilisé pour regrouper les classes d’actifs et leurs sous-catégories, notamment pour la SAA.", category: "Données" },
    { term: "Coupon", expansion: "Revenu obligataire", definition: "Intérêt versé périodiquement par une obligation ; il constitue une composante récurrente du rendement obligataire.", category: "Marchés" },
    { term: "Dividend yield", expansion: "Rendement du dividende", definition: "Dividende rapporté au prix de l’action. Il représente la composante de revenu du total return actions.", category: "Performance" },
    { term: "EIS", expansion: "Stratégie structurée avec Barclays", definition: "Stratégie décrite comme visant à transformer une composante de capital gain en revenu comptabilisé en OPI, notamment pour le périmètre PC.", category: "Stratégies" },
    { term: "Exposition", expansion: "Base de mesure du risque", definition: "Montant économique utilisé pour mesurer la sensibilité ou le risque. Dans les notes, les calculs de duration utilisent les expositions plutôt que la valeur comptable.", category: "Risque" },
    { term: "Gestion allocataire", expansion: "Portfolio allocation management", definition: "Gestion qui décide de la répartition du portefeuille et des stratégies, avec une vue multi-actifs, sans réaliser le stock picking titre par titre.", category: "Organisation" },
    { term: "Leeways", expansion: "Bornes de gestion", definition: "Marges autorisées autour des allocations cibles, par exemple sur la duration ou une sous-catégorie d’actifs, afin d’encadrer les paris tactiques.", category: "Allocation" },
    { term: "Liquidity Planning", expansion: "Planification de liquidité", definition: "Processus bimensuel de prévision des besoins et excédents de cash à environ un mois, avec la poche Trésorerie utilisée comme pivot.", category: "Trésorerie" },
    { term: "MIS Analysis Studio", expansion: "Module d’analyse MIS", definition: "Espace permettant de construire une analyse depuis zéro et de rechercher un instrument via Investment Identifiers puis AIM Identifiers.", category: "Outils" },
    { term: "MIS Explorer", expansion: "Bibliothèque de rapports MIS", definition: "Module privilégié pour réutiliser des rapports standards déjà préparés, notamment par segment LH / PC ou par portefeuille.", category: "Outils" },
    { term: "MIS Handbook", expansion: "Dictionnaire de données MIS", definition: "Référentiel utilisé pour rechercher la définition d’une variable et savoir où la trouver dans MIS.", category: "Données" },
    { term: "OPI", expansion: "Revenu d’investissement opérationnel", definition: "Notion utilisée pour les revenus récurrents d’investissement, notamment dividendes sur actions et coupons sur obligations.", category: "Résultat" },
    { term: "SAA driftée", expansion: "SAA ajustée des mouvements de marché", definition: "Allocation cible stratégique impactée par les évolutions de marché depuis le début de l’année, comparée mensuellement à l’AAA dans MIS.", category: "Allocation" },
    { term: "Stock picking", expansion: "Sélection individuelle de titres", definition: "Choix des obligations, actions ou autres instruments précis. Cette responsabilité relève des Asset Managers plutôt que de la gestion allocataire AIM.", category: "Gestion" },
    { term: "TAA", expansion: "Tactical Asset Allocation", definition: "Ajustement temporaire de l’allocation autour de la SAA pour exploiter une opportunité de marché ou réduire un risque, dans les limites des leeways et budgets.", category: "Allocation" },
    { term: "Total return", expansion: "Rendement total", definition: "Somme de la variation de prix et des revenus distribués ; pour une action, capital gain plus dividend yield.", category: "Performance" },
    { term: "Unit Linked", expansion: "Unités de compte", definition: "Périmètre de contrats en unités de compte. Dans le mode opératoire BPN fourni, ces lignes sont exclues via le filtre de la colonne E pour certaines analyses.", category: "Assurance" },
    { term: "P&L", expansion: "Profit & Loss", definition: "Notion ex post : variation de valeur et gain ou perte effectivement constaté sur une position pendant la période.", category: "Performance" }
  ]
};

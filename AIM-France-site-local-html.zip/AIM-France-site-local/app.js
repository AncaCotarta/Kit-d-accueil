(() => {
  "use strict";

  const data = window.AIM_DATA;
  const config = window.AIM_CONFIG;
  const progressKey = "aim-hub-onboarding-progress-v1";
  const routeTitles = {
    accueil: "Accueil",
    parcours: "Parcours d’arrivée",
    equipe: "Équipe & missions",
    procedures: "Procédures",
    outils: "Outils",
    finance: "Finance",
    glossaire: "Glossaire"
  };

  const state = {
    progress: loadProgress(),
    documentCategory: "Tous",
    glossaryCategory: "all",
    glossaryLetter: "all"
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function escapeHtml(value = "") {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function normalize(value = "") {
    return String(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9&]+/g, " ")
      .trim();
  }

  function loadProgress() {
    try {
      return JSON.parse(localStorage.getItem(progressKey) || "{}") || {};
    } catch {
      return {};
    }
  }

  function saveProgress() {
    try {
      localStorage.setItem(progressKey, JSON.stringify(state.progress));
    } catch {
      showToast("La progression ne peut pas être enregistrée dans ce navigateur.");
    }
  }

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove("is-visible"), 3200);
  }

  function setRoute(route, focusMain = false) {
    const resolved = routeTitles[route] ? route : "accueil";
    $$(".page").forEach((page) => page.classList.toggle("is-active", page.dataset.route === resolved));
    $$('[data-route-link]').forEach((link) => {
      const active = link.dataset.routeLink === resolved;
      link.classList.toggle("is-active", active);
      if (active) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    });
    document.title = `${routeTitles[resolved]} — AIM Hub`;
    closeSidebar();
    closeSearchResults();
    if (focusMain) {
      window.scrollTo({ top: 0, behavior: "smooth" });
      $("#main-content").focus({ preventScroll: true });
    }
  }

  function routeFromHash() {
    return location.hash.replace(/^#/, "") || "accueil";
  }

  function openSidebar() {
    const sidebar = $("#sidebar");
    const scrim = $("#sidebar-scrim");
    sidebar.classList.add("is-open");
    scrim.hidden = false;
    $("#menu-button").setAttribute("aria-expanded", "true");
  }

  function closeSidebar() {
    const sidebar = $("#sidebar");
    const scrim = $("#sidebar-scrim");
    sidebar.classList.remove("is-open");
    scrim.hidden = true;
    $("#menu-button").setAttribute("aria-expanded", "false");
  }

  function pathToFileUrl(path) {
    if (!path) return "";
    if (/^https?:\/\//i.test(path)) return path;
    const normalized = path.replaceAll("\\", "/");
    if (normalized.startsWith("//")) return `file:${encodeURI(normalized)}`;
    if (/^[a-z]:\//i.test(normalized)) return `file:///${encodeURI(normalized)}`;
    return normalized;
  }

  async function copyText(text, successMessage = "Chemin copié.") {
    if (!text) {
      showToast("Aucun chemin n’est renseigné.");
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      showToast(successMessage);
    } catch {
      const helper = document.createElement("textarea");
      helper.value = text;
      helper.setAttribute("readonly", "");
      helper.style.position = "fixed";
      helper.style.opacity = "0";
      document.body.appendChild(helper);
      helper.select();
      document.execCommand("copy");
      helper.remove();
      showToast(successMessage);
    }
  }

  function openConfiguredLink(key) {
    const link = config.links[key];
    if (!link) {
      showToast("Ce lien n’est pas encore configuré.");
      return;
    }
    const target = (link.url || "").trim() || pathToFileUrl(link.path);
    if (!target) {
      showToast("Ce lien n’est pas encore configuré.");
      return;
    }
    window.open(target, "_blank", "noopener,noreferrer");
    if (!link.url) {
      showToast("Ouverture du chemin local. Si le navigateur le bloque, utilisez « Copier le chemin ».");
    }
  }

  function openFile(path) {
    if (!path) return;
    window.open(path, "_blank", "noopener,noreferrer");
  }

  function openDialog(html) {
    const dialog = $("#detail-dialog");
    $("#dialog-content").innerHTML = html;
    if (typeof dialog.showModal === "function") {
      if (!dialog.open) dialog.showModal();
    }
    else dialog.setAttribute("open", "");
  }

  function closeDialog() {
    const dialog = $("#detail-dialog");
    if (typeof dialog.close === "function" && dialog.open) dialog.close();
    else dialog.removeAttribute("open");
  }

  function allOnboardingItems() {
    return data.onboarding.flatMap((group) => group.items);
  }

  function renderOnboarding() {
    const root = $("#onboarding-groups");
    root.innerHTML = data.onboarding.map((group) => {
      const done = group.items.filter((item) => state.progress[item.id]).length;
      const items = group.items.map((item) => {
        const checked = Boolean(state.progress[item.id]);
        return `
          <li class="check-item ${checked ? "is-done" : ""}">
            <input id="check-${escapeHtml(item.id)}" type="checkbox" data-check-id="${escapeHtml(item.id)}" ${checked ? "checked" : ""}>
            <label class="check-control" for="check-${escapeHtml(item.id)}" aria-hidden="true"></label>
            <div class="check-copy">
              <label for="check-${escapeHtml(item.id)}"><strong>${escapeHtml(item.title)}</strong></label>
              <p>${escapeHtml(item.detail)}</p>
              <span class="check-meta">
                <span class="owner-tag">${escapeHtml(item.owner)}</span>
                ${item.linkKey ? `<button type="button" class="micro-link" data-open-link="${escapeHtml(item.linkKey)}">Ouvrir la ressource</button>` : ""}
                ${item.route ? `<button type="button" class="micro-link" data-route-jump="${escapeHtml(item.route)}">Voir le repère métier</button>` : ""}
              </span>
            </div>
          </li>`;
      }).join("");
      return `
        <section class="onboarding-group">
          <header>
            <div><p class="eyebrow">${escapeHtml(group.eyebrow)}</p><h2>${escapeHtml(group.title)}</h2></div>
            <small>${done} / ${group.items.length}</small>
          </header>
          <ul class="checklist">${items}</ul>
        </section>`;
    }).join("");
    updateProgressViews();
  }

  function updateProgressViews() {
    const items = allOnboardingItems();
    const done = items.filter((item) => state.progress[item.id]).length;
    const pct = items.length ? Math.round((done / items.length) * 100) : 0;
    $("#home-progress-value").textContent = `${pct}%`;
    $("#home-progress-ring").style.setProperty("--progress", `${pct * 3.6}deg`);
    $("#home-progress-bar").style.width = `${pct}%`;
    $("#route-progress-count").textContent = `${done} / ${items.length}`;
    $("#route-progress-pct").textContent = `${pct}%`;
    $("#route-progress-bar").style.width = `${pct}%`;
    $("#home-progress-copy").textContent = done === items.length
      ? "Votre parcours est terminé. Pensez à vérifier les évolutions d’accès avec votre manager."
      : `${items.length - done} étape${items.length - done > 1 ? "s" : ""} restante${items.length - done > 1 ? "s" : ""}.`;
  }

  function renderTeam() {
    $("#team-leads").innerHTML = data.teamLeads.map((person) => `
      <article class="team-card">
        <div class="avatar" aria-hidden="true">${escapeHtml(person.initials)}</div>
        <div><h2>${escapeHtml(person.name)}</h2><p>${escapeHtml(person.role)}</p></div>
        <span class="pillar-label">${escapeHtml(person.pillar)}</span>
      </article>`).join("");

    $("#mission-grid").innerHTML = data.missions.map((mission) => `
      <article class="mission-card"><span>${escapeHtml(mission.number)}</span><h3>${escapeHtml(mission.title)}</h3><p>${escapeHtml(mission.description)}</p></article>`).join("");

    $("#wider-team").innerHTML = data.widerTeam.map((person) => `
      <article class="wider-person"><strong>${escapeHtml(person.name)}</strong><span>${escapeHtml(person.role)}</span></article>`).join("");
  }

  function renderBusinessBasics() {
    $("#operating-model").innerHTML = data.operatingModel.map((item, index) => `
      <article class="operating-card" id="operating-${escapeHtml(item.id)}">
        <div class="operating-card-top"><span>${String(index + 1).padStart(2, "0")}</span><small>${escapeHtml(item.label)}</small></div>
        <h3>${escapeHtml(item.title)}</h3>
        <p>${escapeHtml(item.description)}</p>
        <div class="operating-example">${escapeHtml(item.example)}</div>
      </article>`).join("");

    $("#portfolio-segments").innerHTML = data.portfolioSegments.map((item) => `
      <article class="segment-card ${escapeHtml(item.tone)}" id="segment-${escapeHtml(item.id)}">
        <div class="segment-code">${escapeHtml(item.code)}</div>
        <div><p class="eyebrow">${escapeHtml(item.horizon)}</p><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p><small>${escapeHtml(item.entities)}</small></div>
      </article>`).join("");

    $("#allocation-guide").innerHTML = data.allocationGuide.map((item) => `
      <article id="allocation-${escapeHtml(normalize(item.title).replaceAll(" ", "-"))}">
        <span>${escapeHtml(item.number)}</span><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p>
      </article>`).join("");
  }

  function documentExtension(file) {
    return (file.split(".").pop() || "DOC").toUpperCase();
  }

  function renderDocumentFilters() {
    const categories = ["Tous", ...new Set(data.documents.map((doc) => doc.category))];
    $("#document-filters").innerHTML = categories.map((category) => `
      <button type="button" class="${state.documentCategory === category ? "is-active" : ""}" data-document-category="${escapeHtml(category)}">${escapeHtml(category)}</button>`).join("");
  }

  function renderDocuments() {
    const query = normalize($("#document-search").value);
    const docs = data.documents.filter((doc) => {
      const matchesCategory = state.documentCategory === "Tous" || doc.category === state.documentCategory;
      const haystack = normalize(`${doc.title} ${doc.category} ${doc.description} ${doc.freshness}`);
      return matchesCategory && (!query || haystack.includes(query));
    });
    $("#document-grid").innerHTML = docs.length ? docs.map((doc) => {
      const link = doc.linkKey ? config.links[doc.linkKey] : null;
      return `
        <article class="document-card">
          <div class="document-top"><span class="doc-type">${escapeHtml(documentExtension(doc.file))}</span><span class="document-category">${escapeHtml(doc.category)}</span></div>
          <h2>${escapeHtml(doc.title)}</h2>
          <p>${escapeHtml(doc.description)}</p>
          <div class="document-meta">${escapeHtml(doc.freshness)}</div>
          <div class="document-actions">
            <a class="small-button primary" href="${escapeHtml(doc.file)}" target="_blank" rel="noopener">Ouvrir la copie</a>
            ${link ? `<button class="small-button" type="button" data-open-link="${escapeHtml(doc.linkKey)}">Ouvrir la source</button><button class="small-button" type="button" data-copy-link="${escapeHtml(doc.linkKey)}">Copier le chemin</button>` : ""}
          </div>
        </article>`;
    }).join("") : `<div class="empty-state"><strong>Aucun document trouvé</strong><p>Modifiez la recherche ou le filtre.</p></div>`;
  }

  function renderTools() {
    $("#tool-grid").innerHTML = data.tools.map((tool) => `
      <article class="tool-card">
        <div class="tool-card-top"><h3>${escapeHtml(tool.title)}</h3><span class="cadence">${escapeHtml(tool.cadence)}</span></div>
        <p>${escapeHtml(tool.short)}</p>
        <div class="dependency-tags">${tool.dependencies.map((dep) => `<span>${escapeHtml(dep)}</span>`).join("")}</div>
        <div class="tool-card-actions"><button class="small-button primary" type="button" data-tool-id="${escapeHtml(tool.id)}">Voir les étapes</button>${tool.linkKey && config.links[tool.linkKey] ? `<button class="small-button" type="button" data-open-link="${escapeHtml(tool.linkKey)}">Ouvrir la ressource</button>` : ""}</div>
      </article>`).join("");
  }

  function openTool(toolId) {
    const tool = data.tools.find((item) => item.id === toolId);
    if (!tool) return;
    const link = tool.linkKey ? config.links[tool.linkKey] : null;
    openDialog(`
      <div class="dialog-header">
        <p class="eyebrow">Mode opératoire</p>
        <h2>${escapeHtml(tool.title)}</h2>
        <p>${escapeHtml(tool.short)}</p>
        <div class="dialog-meta"><span>${escapeHtml(tool.cadence)}</span>${tool.dependencies.map((dep) => `<span>${escapeHtml(dep)}</span>`).join("")}</div>
      </div>
      <h3>Étapes clés</h3>
      <ol class="dialog-steps">${tool.steps.map((step) => `<li>${escapeHtml(step)}</li>`).join("")}</ol>
      ${tool.notes?.length ? `<div class="dialog-notes"><h3>Points de vigilance</h3><ul>${tool.notes.map((note) => `<li>${escapeHtml(note)}</li>`).join("")}</ul></div>` : ""}
      ${tool.image ? `<button class="tool-figure" type="button" data-image-src="${escapeHtml(tool.image)}" data-image-title="${escapeHtml(tool.title)}"><img src="${escapeHtml(tool.image)}" alt="${escapeHtml(tool.imageAlt || tool.title)}"><span>Voir la capture explicative en grand</span></button>` : ""}
      ${link ? `<div class="dialog-path"><code>${escapeHtml(link.path || link.url)}</code></div><div class="dialog-actions"><button class="primary-button" type="button" data-open-link="${escapeHtml(tool.linkKey)}">Ouvrir la ressource</button><button class="secondary-button" type="button" data-copy-link="${escapeHtml(tool.linkKey)}">Copier le chemin</button></div>` : ""}`);
  }

  function renderFinance() {
    $("#finance-grid").innerHTML = data.financeLinks.map((item) => `
      <article class="finance-card"><p class="eyebrow">Fichier Finance</p><h2>${escapeHtml(item.title)}</h2><p>${escapeHtml(item.description)}</p><div class="finance-note">${escapeHtml(item.note)}</div><button class="small-button primary" type="button" data-open-link="${escapeHtml(item.linkKey)}">Ouvrir / localiser</button></article>`).join("");
  }

  function glossaryCategories() {
    return [...new Set(data.glossary.map((item) => item.category))].sort((a, b) => a.localeCompare(b, "fr"));
  }

  function renderGlossaryControls() {
    $("#glossary-total").textContent = data.glossary.length;
    $("#glossary-category").innerHTML = `<option value="all">Toutes les catégories</option>${glossaryCategories().map((category) => `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`).join("")}`;

    const available = new Set(data.glossary.map((item) => normalize(item.term).charAt(0).toUpperCase()));
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
    $("#alphabet-filter").innerHTML = `<button type="button" data-letter="all" class="is-active">Tous</button>${letters.map((letter) => `<button type="button" data-letter="${letter}" ${available.has(letter) ? "" : "disabled"}>${letter}</button>`).join("")}`;
  }

  function filteredGlossary() {
    const query = normalize($("#glossary-search").value);
    return data.glossary
      .map((item, index) => ({ ...item, originalIndex: index }))
      .filter((item) => {
        const first = normalize(item.term).charAt(0).toUpperCase();
        const matchesLetter = state.glossaryLetter === "all" || first === state.glossaryLetter;
        const matchesCategory = state.glossaryCategory === "all" || item.category === state.glossaryCategory;
        const haystack = normalize(`${item.term} ${item.expansion} ${item.definition} ${item.category}`);
        return matchesLetter && matchesCategory && (!query || haystack.includes(query));
      })
      .sort((a, b) => a.term.localeCompare(b.term, "fr", { sensitivity: "base" }));
  }

  function renderGlossary() {
    const items = filteredGlossary();
    $("#glossary-summary").textContent = `${items.length} terme${items.length > 1 ? "s" : ""} affiché${items.length > 1 ? "s" : ""}`;
    $("#glossary-empty").hidden = items.length > 0;
    $("#glossary-grid").innerHTML = items.map((item) => `
      <article class="glossary-card" data-glossary-card="${escapeHtml(item.term)}">
        <div class="glossary-card-top"><h2 class="glossary-term">${escapeHtml(item.term)}</h2><span class="glossary-category">${escapeHtml(item.category)}</span></div>
        <p class="glossary-expansion">${escapeHtml(item.expansion)}</p>
        <p class="glossary-definition">${escapeHtml(item.definition)}</p>
        <div class="glossary-footer">
          <span class="needs-update">${item.status ? escapeHtml(item.status) : ""}</span>
          ${item.images?.length ? `<button type="button" class="image-link" data-glossary-index="${item.originalIndex}">Voir le schéma</button>` : ""}
        </div>
      </article>`).join("");
  }

  function openGlossaryItem(index) {
    const item = data.glossary[Number(index)];
    if (!item) return;
    openDialog(`
      <div class="dialog-header"><p class="eyebrow">${escapeHtml(item.category)}</p><h2>${escapeHtml(item.term)}</h2><p><strong>${escapeHtml(item.expansion)}</strong></p><p>${escapeHtml(item.definition)}</p>${item.status ? `<div class="dialog-meta"><span>${escapeHtml(item.status)}</span></div>` : ""}</div>
      <div class="dialog-gallery">${(item.images || []).map((image) => `<img class="dialog-image" src="${escapeHtml(image)}" alt="Schéma de référence pour ${escapeHtml(item.term)}">`).join("")}</div>`);
  }

  function openImage(src, title) {
    openDialog(`<div class="dialog-header"><p class="eyebrow">Schéma de référence</p><h2>${escapeHtml(title || "Illustration")}</h2></div><img class="dialog-image" src="${escapeHtml(src)}" alt="${escapeHtml(title || "Schéma de référence")}">`);
  }

  function buildSearchIndex() {
    const items = [];
    data.glossary.forEach((item, index) => items.push({ type: "Glossaire", title: item.term, detail: item.expansion, route: "glossaire", action: "glossary", value: item.term, index }));
    data.documents.forEach((item) => items.push({ type: "Document", title: item.title, detail: item.category, route: "procedures", action: "document", value: item.title }));
    data.tools.forEach((item) => items.push({ type: "Outil", title: item.title, detail: item.short, route: "outils", action: "tool", value: item.id }));
    data.teamLeads.forEach((item) => items.push({ type: "Équipe", title: item.name, detail: item.role, route: "equipe", action: "team", value: item.name }));
    data.operatingModel.forEach((item) => items.push({ type: "Repère", title: item.label, detail: item.title, route: "equipe", action: "learning", value: `operating-${item.id}` }));
    data.portfolioSegments.forEach((item) => items.push({ type: "Portefeuille", title: item.code, detail: `${item.title} — ${item.horizon}`, route: "equipe", action: "learning", value: `segment-${item.id}` }));
    data.allocationGuide.forEach((item) => items.push({ type: "Allocation", title: item.title, detail: item.description, route: "equipe", action: "learning", value: `allocation-${normalize(item.title).replaceAll(" ", "-")}` }));
    data.onboarding.flatMap((group) => group.items).forEach((item) => items.push({ type: "Parcours", title: item.title, detail: item.owner, route: "parcours", action: "onboarding", value: item.id }));
    data.financeLinks.forEach((item) => items.push({ type: "Finance", title: item.title, detail: item.description, route: "finance", action: "finance", value: item.title }));
    return items;
  }

  const searchIndex = buildSearchIndex();

  function renderGlobalSearch() {
    const input = $("#global-search");
    const results = $("#search-results");
    const query = normalize(input.value);
    if (query.length < 2) {
      closeSearchResults();
      return;
    }
    const matches = searchIndex
      .map((item) => ({ item, score: normalize(item.title).startsWith(query) ? 0 : normalize(`${item.title} ${item.detail}`).includes(query) ? 1 : 99 }))
      .filter(({ score }) => score < 99)
      .sort((a, b) => a.score - b.score || a.item.title.localeCompare(b.item.title, "fr"))
      .slice(0, 10)
      .map(({ item }) => item);
    results.hidden = false;
    input.setAttribute("aria-expanded", "true");
    results.innerHTML = matches.length ? matches.map((item) => `
      <button type="button" role="option" data-search-action="${escapeHtml(item.action)}" data-search-route="${escapeHtml(item.route)}" data-search-value="${escapeHtml(item.value)}" ${item.index !== undefined ? `data-search-index="${item.index}"` : ""}>
        <small>${escapeHtml(item.type)}</small><span><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.detail)}</span></span>
      </button>`).join("") : `<div class="search-empty">Aucun résultat pour « ${escapeHtml(input.value)} »</div>`;
  }

  function closeSearchResults() {
    $("#search-results").hidden = true;
    $("#global-search").setAttribute("aria-expanded", "false");
  }

  function executeSearchResult(button) {
    const { searchAction: action, searchRoute: route, searchValue: value, searchIndex: index } = button.dataset;
    location.hash = route;
    setRoute(route, true);
    $("#global-search").value = "";
    closeSearchResults();
    if (action === "glossary") {
      state.glossaryCategory = "all";
      state.glossaryLetter = "all";
      $("#glossary-category").value = "all";
      $("#glossary-search").value = value;
      $$("[data-letter]").forEach((el) => el.classList.toggle("is-active", el.dataset.letter === "all"));
      renderGlossary();
      setTimeout(() => $(`[data-glossary-card="${CSS.escape(value)}"]`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 80);
      if (index !== undefined && data.glossary[Number(index)]?.images?.length) setTimeout(() => openGlossaryItem(index), 180);
    } else if (action === "tool") {
      setTimeout(() => openTool(value), 80);
    } else if (action === "document") {
      $("#document-search").value = value;
      state.documentCategory = "Tous";
      renderDocumentFilters();
      renderDocuments();
    } else if (action === "learning") {
      setTimeout(() => document.getElementById(value)?.scrollIntoView({ behavior: "smooth", block: "center" }), 80);
    }
  }

  function bindEvents() {
    window.addEventListener("hashchange", () => setRoute(routeFromHash(), true));
    $("#menu-button").addEventListener("click", () => $("#sidebar").classList.contains("is-open") ? closeSidebar() : openSidebar());
    $("#sidebar-scrim").addEventListener("click", closeSidebar);

    document.addEventListener("click", (event) => {
      const routeJump = event.target.closest("[data-route-jump]");
      if (routeJump) location.hash = routeJump.dataset.routeJump;

      const openLinkButton = event.target.closest("[data-open-link]");
      if (openLinkButton) {
        event.preventDefault();
        openConfiguredLink(openLinkButton.dataset.openLink);
      }

      const copyLinkButton = event.target.closest("[data-copy-link]");
      if (copyLinkButton) {
        event.preventDefault();
        const link = config.links[copyLinkButton.dataset.copyLink];
        copyText(link?.url || link?.path, "Chemin de la ressource copié.");
      }

      const openFileButton = event.target.closest("[data-open-file]");
      if (openFileButton) openFile(openFileButton.dataset.openFile);

      const toolButton = event.target.closest("[data-tool-id]");
      if (toolButton) openTool(toolButton.dataset.toolId);

      const imageButton = event.target.closest("[data-image-src]");
      if (imageButton) openImage(imageButton.dataset.imageSrc, imageButton.dataset.imageTitle);

      const glossaryButton = event.target.closest("[data-glossary-index]");
      if (glossaryButton) openGlossaryItem(glossaryButton.dataset.glossaryIndex);

      const closeButton = event.target.closest("[data-dialog-close]");
      if (closeButton) closeDialog();

      const categoryButton = event.target.closest("[data-document-category]");
      if (categoryButton) {
        state.documentCategory = categoryButton.dataset.documentCategory;
        renderDocumentFilters();
        renderDocuments();
      }

      const letterButton = event.target.closest("[data-letter]");
      if (letterButton && !letterButton.disabled) {
        state.glossaryLetter = letterButton.dataset.letter;
        $$("[data-letter]").forEach((button) => button.classList.toggle("is-active", button === letterButton));
        renderGlossary();
      }

      const searchButton = event.target.closest("[data-search-action]");
      if (searchButton) executeSearchResult(searchButton);

      if (!event.target.closest(".global-search-wrap")) closeSearchResults();
    });

    $("#detail-dialog").addEventListener("click", (event) => {
      const rect = event.currentTarget.getBoundingClientRect();
      const outside = event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom;
      if (outside) closeDialog();
    });

    $("#onboarding-groups").addEventListener("change", (event) => {
      const input = event.target.closest("[data-check-id]");
      if (!input) return;
      state.progress[input.dataset.checkId] = input.checked;
      saveProgress();
      renderOnboarding();
    });

    $("#reset-progress").addEventListener("click", () => {
      if (!window.confirm("Réinitialiser toutes les étapes du parcours ?")) return;
      state.progress = {};
      saveProgress();
      renderOnboarding();
      showToast("Le parcours a été réinitialisé.");
    });

    $("#document-search").addEventListener("input", renderDocuments);
    $("#glossary-search").addEventListener("input", renderGlossary);
    $("#glossary-category").addEventListener("change", (event) => {
      state.glossaryCategory = event.target.value;
      renderGlossary();
    });

    $("#global-search").addEventListener("input", renderGlobalSearch);
    $("#global-search").addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        closeSearchResults();
        event.currentTarget.blur();
      }
      if (event.key === "ArrowDown") {
        event.preventDefault();
        $("#search-results button")?.focus();
      }
    });

    document.addEventListener("keydown", (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        $("#global-search").focus();
      }
      if (event.key === "Escape") {
        closeSidebar();
        closeSearchResults();
      }
    });
  }

  function init() {
    $("#sidebar-version").textContent = `Version ${config.version}`;
    $("#footer-update").textContent = `Mis à jour le ${config.updatedAt}`;
    renderOnboarding();
    renderTeam();
    renderBusinessBasics();
    renderDocumentFilters();
    renderDocuments();
    renderTools();
    renderFinance();
    renderGlossaryControls();
    renderGlossary();
    bindEvents();
    setRoute(routeFromHash());
  }

  init();
})();
